<div>
    Dish From Actions View: {{ $row->id }}
</div>
