<span>{!! $noDataLabel !!}</span>
