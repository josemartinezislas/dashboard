<tr
    class="{{ theme_style($theme, 'table.header.tr') }}"
>
    <th
        class="{{ theme_style($theme, 'table.body.tdEmpty') }}"
        colspan="999"
    >
        {!! $this->processNoDataLabel !!}
    </th>
</tr>
