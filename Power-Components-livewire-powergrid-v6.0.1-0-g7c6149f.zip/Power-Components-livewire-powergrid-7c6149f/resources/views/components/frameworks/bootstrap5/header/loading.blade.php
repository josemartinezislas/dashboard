<div class="d-flex align-items-center ps-4">
    <div
        wire:loading.class="spinner-border"
        class="text-primary"
        role="status"
    >
        <span class="visually-hidden">Loading...</span>
    </div>
</div>
