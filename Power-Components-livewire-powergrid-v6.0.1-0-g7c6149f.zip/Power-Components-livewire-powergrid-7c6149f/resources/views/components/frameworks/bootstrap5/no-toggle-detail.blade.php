<td
    class="{{ theme_style($theme, 'table.body.td') }}"
></td>
