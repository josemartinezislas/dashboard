<?php

namespace PowerComponents\LivewirePowerGrid;

use Illuminate\View\Concerns\ManagesLoops;

class ManageLoops
{
    use ManagesLoops;
}
