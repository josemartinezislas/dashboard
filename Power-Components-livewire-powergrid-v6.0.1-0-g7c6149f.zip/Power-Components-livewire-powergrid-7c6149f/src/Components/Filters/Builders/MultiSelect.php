<?php

namespace PowerComponents\LivewirePowerGrid\Components\Filters\Builders;

class MultiSelect extends BuilderBase
{
    use WithMultiSelectBuilder;
}
