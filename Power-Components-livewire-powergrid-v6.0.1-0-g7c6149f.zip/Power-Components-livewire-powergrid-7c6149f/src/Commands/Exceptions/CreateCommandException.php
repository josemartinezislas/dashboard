<?php

namespace PowerComponents\LivewirePowerGrid\Commands\Exceptions;

use Exception;

final class CreateCommandException extends Exception
{
    /** @var string */
    protected $message = '';
}
